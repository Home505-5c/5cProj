
![Logo](https://raw.githubusercontent.com/SchoolIzBoring/Unblocked-Websites/main/logo.png)


# Unblocked Websites

Unblocked Websites is an Open Source tool Website for school that includes games, proxies, tools, and more



## Demo
schoolizboring.github.io/Unblocked-Websites/


## Authors

- [@SchoolIzBoring](https://github.com/SchoolIzBoring)


## License

[MIT](https://choosealicense.com/licenses/mit/)

